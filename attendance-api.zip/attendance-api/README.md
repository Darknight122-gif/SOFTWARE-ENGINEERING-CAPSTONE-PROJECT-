# Attendance API

A simple REST API for recording student attendance, built with Node.js and Express. Data is stored in memory (a JavaScript array) — no database required.

## Endpoints

| Method | Endpoint      | Description                  |
|--------|---------------|-------------------------------|
| GET    | `/attendance` | Returns the list of students recorded so far |
| POST   | `/attendance` | Adds a new attendance record |

### POST body example
```json
{
  "name": "John Doe",
  "matricNo": "CSC001"
}
```

### POST response example
```json
{
  "message": "Attendance recorded successfully.",
  "data": {
    "id": 1,
    "name": "John Doe",
    "matricNo": "CSC001",
    "timestamp": "2026-08-12T21:00:00.000Z"
  }
}
```

## Setup Steps

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd attendance-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the server**
   ```bash
   npm start
   ```
   The API will run at `http://localhost:3000`.

4. **Test the endpoints**

   Using curl:
   ```bash
   # Get all attendance records
   curl http://localhost:3000/attendance

   # Add a new record
   curl -X POST http://localhost:3000/attendance \
     -H "Content-Type: application/json" \
     -d '{"name": "John Doe", "matricNo": "CSC001"}'
   ```

   Or use Postman / Insomnia / Thunder Client:
   - `GET http://localhost:3000/attendance`
   - `POST http://localhost:3000/attendance` with a JSON body as shown above

## Screenshots

> Add screenshots here after testing on your machine — e.g. a Postman screenshot of the GET request showing the returned array, and a POST request showing the 201 response with the new record.

- `screenshots/get-attendance.png`
- `screenshots/post-attendance.png`

## Notes
- Data resets every time the server restarts (in-memory storage only, no database).
- Both `name` and `matricNo` are required fields; the API returns a `400` error if either is missing.
