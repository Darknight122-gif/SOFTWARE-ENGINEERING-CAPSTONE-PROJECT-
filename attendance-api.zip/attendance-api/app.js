const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory data store
let attendanceRecords = [];

// GET /attendance -> return list of students
app.get('/attendance', (req, res) => {
  res.status(200).json({
    count: attendanceRecords.length,
    data: attendanceRecords
  });
});

// POST /attendance -> add a student's attendance
app.post('/attendance', (req, res) => {
  const { name, matricNo } = req.body;

  if (!name || !matricNo) {
    return res.status(400).json({
      error: 'Both "name" and "matricNo" are required.'
    });
  }

  const newRecord = {
    id: attendanceRecords.length + 1,
    name,
    matricNo,
    timestamp: new Date().toISOString()
  };

  attendanceRecords.push(newRecord);

  res.status(201).json({
    message: 'Attendance recorded successfully.',
    data: newRecord
  });
});

// Fallback for unknown routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`Attendance API running on http://localhost:${PORT}`);
});
