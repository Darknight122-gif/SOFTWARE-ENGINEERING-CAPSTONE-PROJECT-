const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory data store
let movies = [];

// GET /movies -> return list of movies
app.get('/movies', (req, res) => {
  res.status(200).json({
    count: movies.length,
    data: movies
  });
});

// POST /movies -> add a movie
app.post('/movies', (req, res) => {
  const { title, genre, year } = req.body;

  if (!title || !genre || !year) {
    return res.status(400).json({
      error: 'Fields "title", "genre" and "year" are required.'
    });
  }

  const newMovie = {
    id: movies.length + 1,
    title,
    genre,
    year
  };

  movies.push(newMovie);

  res.status(201).json({
    message: 'Movie added successfully.',
    data: newMovie
  });
});

// Fallback for unknown routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`Movie Collection API running on http://localhost:${PORT}`);
});
