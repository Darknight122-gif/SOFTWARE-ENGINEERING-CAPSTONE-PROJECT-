# Movie Collection API

A simple REST API for storing favourite movies, built with Node.js and Express. Data is stored in memory (a JavaScript array) — no database required.

## Endpoints

| Method | Endpoint  | Description                  |
|--------|-----------|--------------------------------|
| GET    | `/movies` | Returns the list of movies     |
| POST   | `/movies` | Adds a new movie                |

### POST body example
```json
{
  "title": "Black Panther",
  "genre": "Action",
  "year": 2018
}
```

### POST response example
```json
{
  "message": "Movie added successfully.",
  "data": {
    "id": 1,
    "title": "Black Panther",
    "genre": "Action",
    "year": 2018
  }
}
```

## Setup Steps

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd movie-collection-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the server**
   ```bash
   npm start
   ```
   The API will run at `http://localhost:3000`.

4. **Test the endpoints**

   Using curl:
   ```bash
   # Get all movies
   curl http://localhost:3000/movies

   # Add a new movie
   curl -X POST http://localhost:3000/movies \
     -H "Content-Type: application/json" \
     -d '{"title": "Black Panther", "genre": "Action", "year": 2018}'
   ```

   Or use Postman / Insomnia / Thunder Client:
   - `GET http://localhost:3000/movies`
   - `POST http://localhost:3000/movies` with a JSON body as shown above

## Screenshots

> Add screenshots here after testing on your machine — e.g. a Postman screenshot of the GET request showing the returned array, and a POST request showing the 201 response with the new movie.

- `screenshots/get-movies.png`
- `screenshots/post-movies.png`

## Notes
- Data resets every time the server restarts (in-memory storage only, no database).
- `title`, `genre`, and `year` are all required fields; the API returns a `400` error if any is missing.
