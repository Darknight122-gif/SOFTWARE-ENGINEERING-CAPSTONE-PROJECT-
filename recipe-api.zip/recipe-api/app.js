const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory data store
let recipes = [];

// GET /recipes -> return list of recipes
app.get('/recipes', (req, res) => {
  res.status(200).json({
    count: recipes.length,
    data: recipes
  });
});

// POST /recipes -> add a recipe
app.post('/recipes', (req, res) => {
  const { name, ingredient, cookingTime } = req.body;

  if (!name || !ingredient || !cookingTime) {
    return res.status(400).json({
      error: 'Fields "name", "ingredient" and "cookingTime" are required.'
    });
  }

  const newRecipe = {
    id: recipes.length + 1,
    name,
    ingredient,
    cookingTime
  };

  recipes.push(newRecipe);

  res.status(201).json({
    message: 'Recipe added successfully.',
    data: newRecipe
  });
});

// Fallback for unknown routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

app.listen(PORT, () => {
  console.log(`Recipe API running on http://localhost:${PORT}`);
});
