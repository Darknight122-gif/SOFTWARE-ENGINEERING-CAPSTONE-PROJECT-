# Recipe API

A simple REST API for storing recipes, built with Node.js and Express. Data is stored in memory (a JavaScript array) — no database required.

## Endpoints

| Method | Endpoint   | Description                    |
|--------|------------|----------------------------------|
| GET    | `/recipes` | Returns the list of recipes      |
| POST   | `/recipes` | Adds a new recipe                 |

### POST body example
```json
{
  "name": "Jollof Rice",
  "ingredient": "Rice",
  "cookingTime": "45 minutes"
}
```

### POST response example
```json
{
  "message": "Recipe added successfully.",
  "data": {
    "id": 1,
    "name": "Jollof Rice",
    "ingredient": "Rice",
    "cookingTime": "45 minutes"
  }
}
```

## Setup Steps

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd recipe-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the server**
   ```bash
   npm start
   ```
   The API will run at `http://localhost:3000`.

4. **Test the endpoints**

   Using curl:
   ```bash
   # Get all recipes
   curl http://localhost:3000/recipes

   # Add a new recipe
   curl -X POST http://localhost:3000/recipes \
     -H "Content-Type: application/json" \
     -d '{"name": "Jollof Rice", "ingredient": "Rice", "cookingTime": "45 minutes"}'
   ```

   Or use Postman / Insomnia / Thunder Client:
   - `GET http://localhost:3000/recipes`
   - `POST http://localhost:3000/recipes` with a JSON body as shown above

## Screenshots

> Add screenshots here after testing on your machine — e.g. a Postman screenshot of the GET request showing the returned array, and a POST request showing the 201 response with the new recipe.

- `screenshots/get-recipes.png`
- `screenshots/post-recipes.png`

## Notes
- Data resets every time the server restarts (in-memory storage only, no database).
- `name`, `ingredient`, and `cookingTime` are all required fields; the API returns a `400` error if any is missing.
